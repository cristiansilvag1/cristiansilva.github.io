# Portafolio de Datos - Cristian Silva

Esta es una plantilla básica de portafolio creada para GitHub Pages.

## Estructura
- `index.html`: página principal del portafolio
- `assets/css/style.css`: estilos globales
- `projects/`: páginas de detalle de proyectos

## Cómo usar
1. Renombrar la carpeta a `tuusuario.github.io` (o crear un repo con ese nombre) y subir el contenido.
2. Activar GitHub Pages en Settings → Pages → Branch: main → /(root).
3. Enlazar tus proyectos reales y ajustar los textos/contacto.
